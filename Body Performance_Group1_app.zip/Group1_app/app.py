from flask import Flask, render_template, request
import pickle

# Load the trained model
model = pickle.load(open('C:/Users/USER/Downloads/body perf pic_vid/Group1_app/body_perf_pickle_file.pkl', 'rb'))

# Create a Flask app
app = Flask(__name__)

# Create an HTML form for user input
@app.route('/')
def home():
    return render_template('index1.html')

# Create a Flask route to handle model prediction
@app.route('/predict', methods=['POST'])
def predict():
    # Get input data from form
    input_data = [float(x) for x in request.form.values()]
    
    # Preprocess input data if necessary
    
    # Use loaded model to make prediction
    prediction = model.predict([input_data])[0]
    if prediction == 0:
        prediction_label = "A : Elite athlete"
        message = "Congratulations! You're an elite athlete. You've worked hard to achieve this level of fitness, and you should be proud of what you've accomplished. Keep up the great work!"
    elif prediction == 1:
        prediction_label = "B : Above average" 
        message = "Great job! You're above average, which means you're well on your way to reaching your fitness goals. Keep pushing yourself and you'll continue to see progress."
    elif prediction == 2:
        prediction_label = "C : Average"
        message = "You're at an average level of fitness, which means there's room for improvement. But don't worry - with dedication and hard work, you can reach the next level and improve your overall body performance."
    else :
        prediction_label = "D : Below average"
        message = "Don't be discouraged - everyone starts somewhere. You may be below average now, but with consistent effort and dedication, you can improve your fitness and reach your goals. Keep pushing yourself and never give up."

    prediction_prob = model.predict_proba([input_data])[0]
    A = round(prediction_prob[0]*100,4)
    B = round(prediction_prob[1]*100,4)
    C = round(prediction_prob[2]*100,4)
    D = round(prediction_prob[3]*100,4)

    # Return prediction to user
    return render_template('predict1.html', prediction=prediction_label, message=message,A=A, B=B, C=C, D=D)

# Run the Flask app
if __name__ == '__main__':
    app.run(debug=True)